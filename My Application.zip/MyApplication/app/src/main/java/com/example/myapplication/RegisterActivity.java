package com.example.My Application;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register); // Remplacez par votre fichier XML de la page de création

        Button createAccountButton = findViewById(R.id.button); // Assurez-vous que l'ID correspond à celui dans le fichier XML

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirige vers la page de connexion
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
                finish(); // Optionnel : ferme la page actuelle pour éviter le retour
            }
        });
    }
}
